
from telegram import Update
from telegram.ext import Application, MessageHandler, filters, CallbackContext, CommandHandler

TOKEN = "7909533678:AAFyw4itwATXI5hEG9WvM8yIf_WuLuu8YvE"

# Función para cargar palabras desde un archivo
def cargar_palabras(archivo):
    try:
        with open(archivo, 'r', encoding='utf-8') as file:
            return set(line.strip().lower() for line in file)
    except FileNotFoundError:
        print(f"Error: No se encontró {archivo}")
        return set()

# Cargar listas de palabras
palabras_validas = cargar_palabras('palabras.txt')
palabras_prohibidas = cargar_palabras('groserias.txt')
palabras_especiales = cargar_palabras('especiales.txt')

async def start(update: Update, context: CallbackContext):
    await update.message.reply_text("¡Hola! Envíame un mensaje y verificaré las palabras.")

async def analizar_mensaje(update: Update, context: CallbackContext):
    user_text = update.message.text.lower()
    palabras = user_text.split()
    respuesta = ""
    
    for palabra in palabras:
        palabra_lower = palabra.lower()
        if palabra_lower in palabras_prohibidas:
            respuesta += f"⚠️ La palabra '{palabra}' está en 'groserias.txt'\n"
        elif palabra_lower in palabras_especiales:
            respuesta += f"⭐ La palabra '{palabra}' está en 'especiales.txt'\n"
        elif palabra_lower in palabras_validas:
            respuesta += f"✅ La palabra '{palabra}' está en 'palabras.txt'\n"
    
    if respuesta:
        await update.message.reply_text(respuesta)
    else:
        await update.message.reply_text("No se encontraron coincidencias en los archivos.")

# Configuración del bot
app = Application.builder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, analizar_mensaje))

print("🤖 Bot de filtrado iniciado...")
app.run_polling()
